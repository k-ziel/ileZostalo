import Adw from 'gi://Adw';
import Gdk from 'gi://Gdk';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';
import Pango from 'gi://Pango';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

const toHex = rgba => {
    const c = v => Math.round(v * 255).toString(16).padStart(2, '0');
    return `#${c(rgba.red)}${c(rgba.green)}${c(rgba.blue)}`;
};

export default class SerekPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        window._settings = settings; // trzymamy referencję do końca życia okna

        const page = new Adw.PreferencesPage({
            title: 'Serek – plan lekcji',
            icon_name: 'preferences-system-time-symbolic',
        });
        window.add(page);

        const spin = (title, key, lower, upper, step, subtitle = '') => {
            const row = new Adw.SpinRow({
                title,
                subtitle,
                adjustment: new Gtk.Adjustment({
                    lower, upper, step_increment: step, page_increment: step * 5,
                }),
            });
            settings.bind(key, row, 'value', Gio.SettingsBindFlags.DEFAULT);
            return row;
        };

        const toggle = (title, key, subtitle = '') => {
            const row = new Adw.SwitchRow({title, subtitle});
            settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
            return row;
        };

        const color = (title, key) => {
            const row = new Adw.ActionRow({title});
            const button = new Gtk.ColorDialogButton({
                valign: Gtk.Align.CENTER,
                dialog: new Gtk.ColorDialog({with_alpha: false, title}),
            });
            const rgba = new Gdk.RGBA();
            if (rgba.parse(settings.get_string(key)))
                button.rgba = rgba;
            button.connect('notify::rgba', () => {
                const hex = toHex(button.rgba);
                if (hex !== settings.get_string(key))
                    settings.set_string(key, hex);
            });
            row.add_suffix(button);
            row.activatable_widget = button;
            return row;
        };

        // --- Kolory i ostrzeżenie ---
        const colors = new Adw.PreferencesGroup({title: 'Kolory i ostrzeżenie'});
        colors.add(color('Kolor tekstu', 'text-color'));
        colors.add(color('Kolor ostrzeżenia', 'warn-color'));
        colors.add(spin('Ostrzeżenie poniżej (minuty)', 'warn-minutes', 0, 30, 1,
            'Poniżej tylu minut do końca lekcji zmienia się kolor. 0 = wyłączone.'));
        page.add(colors);

        // --- Tekst ---
        const text = new Adw.PreferencesGroup({title: 'Tekst'});

        const fontRow = new Adw.ActionRow({title: 'Czcionka'});
        const updateSubtitle = () => {
            const fam = settings.get_string('font-family');
            fontRow.subtitle = fam === '' ? 'Domyślna czcionka systemu' : fam;
        };
        const fontButton = new Gtk.FontDialogButton({
            valign: Gtk.Align.CENTER,
            level: Gtk.FontLevel.FAMILY,
            dialog: new Gtk.FontDialog({title: 'Wybierz czcionkę'}),
        });
        const current = settings.get_string('font-family');
        if (current !== '')
            fontButton.font_desc = Pango.FontDescription.from_string(current);
        fontButton.connect('notify::font-desc', () => {
            const fam = fontButton.font_desc?.get_family() ?? '';
            if (fam !== '' && fam !== settings.get_string('font-family'))
                settings.set_string('font-family', fam);
        });
        const resetButton = new Gtk.Button({
            icon_name: 'edit-clear-symbolic',
            tooltip_text: 'Przywróć domyślną czcionkę systemu',
            valign: Gtk.Align.CENTER,
            css_classes: ['flat'],
        });
        resetButton.connect('clicked', () => settings.set_string('font-family', ''));
        settings.connect('changed::font-family', updateSubtitle);
        updateSubtitle();
        fontRow.add_suffix(resetButton);
        fontRow.add_suffix(fontButton);
        text.add(fontRow);

        text.add(toggle('Pogrubiona', 'font-bold'));
        text.add(spin('Rozmiar czcionki (pt)', 'font-size', 8, 40, 1));
        text.add(toggle('Napis „Do końca:”', 'show-end-label'));
        page.add(text);

        // --- Tło ---
        const background = new Adw.PreferencesGroup({title: 'Tło'});
        background.add(toggle('Rysuj własne tło', 'draw-background',
            'Wyłączone = przezroczyste, widać tylko tekst na pasku.'));
        background.add(color('Kolor tła', 'bg-color'));
        page.add(background);

        // --- Cień ---
        const shadow = new Adw.PreferencesGroup({title: 'Cień tekstu'});
        shadow.add(toggle('Cień / obrys tekstu', 'shadow'));
        shadow.add(color('Kolor obrysu', 'outline-color'));
        shadow.add(spin('Krycie obrysu (%)', 'outline-alpha', 0, 100, 10));
        page.add(shadow);

        // --- Położenie ---
        const placement = new Adw.PreferencesGroup({title: 'Położenie na pasku'});
        const positions = ['left', 'center', 'right'];
        const positionRow = new Adw.ComboRow({
            title: 'Strona paska',
            model: Gtk.StringList.new(['Lewa', 'Środek (przy zegarze)', 'Prawa']),
            selected: Math.max(0, positions.indexOf(settings.get_string('position'))),
        });
        positionRow.connect('notify::selected', () => {
            settings.set_string('position', positions[positionRow.selected]);
        });
        placement.add(positionRow);
        page.add(placement);
    }
}
