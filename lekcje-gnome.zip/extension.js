import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Pango from 'gi://Pango';
import St from 'gi://St';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

// Godziny lekcji z planu zajęć: [start, koniec]
const LESSONS = [
    ['07:10', '07:55'], ['08:00', '08:45'], ['08:50', '09:35'],
    ['09:40', '10:25'], ['10:40', '11:25'], ['11:30', '12:15'],
    ['12:30', '13:15'], ['13:20', '14:05'], ['14:10', '14:55'],
    ['15:00', '15:45'], ['15:50', '16:35'],
];

const WEEKEND_TEXT = 'Weekend – brak lekcji';
const DONE_TEXT = 'Lekcje na dziś zakończone';

const pad = n => String(n).padStart(2, '0');
const toSec = hhmm => {
    const [h, m] = hhmm.split(':').map(Number);
    return h * 3600 + m * 60;
};
const fmt = diff => `${pad(Math.floor(diff / 60))}:${pad(diff % 60)}`;

/**
 * Zwraca {text, remaining}; remaining = sekundy do końca lekcji albo -1.
 * Ta sama logika co compute_text() w wersji Tkinter.
 */
function computeState(showEndLabel) {
    const now = new Date();
    const dow = now.getDay(); // 0 = niedziela, 6 = sobota
    if (dow === 0 || dow === 6)
        return {text: WEEKEND_TEXT, remaining: -1};

    const t = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
    for (const [start, end] of LESSONS) {
        const s = toSec(start);
        const e = toSec(end);
        if (t >= s && t < e) {
            const left = e - t;
            const label = showEndLabel ? 'Do końca: ' : '';
            return {text: `${label}${fmt(left)}`, remaining: left};
        } else if (t < s) {
            return {text: `Do dzwonka: ${fmt(s - t)}`, remaining: -1};
        }
    }
    return {text: DONE_TEXT, remaining: -1};
}

function hexToRgba(hex, alpha) {
    const m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i.exec(hex ?? '');
    if (!m)
        return hex;
    return `rgba(${parseInt(m[1], 16)}, ${parseInt(m[2], 16)}, ${parseInt(m[3], 16)}, ${alpha})`;
}

const Indicator = GObject.registerClass(
class SerekIndicator extends PanelMenu.Button {
    _init(settings, openPrefs) {
        super._init(0.0, 'Serek – plan lekcji', false);
        this._settings = settings;
        this._text = '';
        this._remaining = -1;
        this._warning = false;
        this._fixedWidth = 0;
        this._timeoutId = 0;
        this._settingsIds = [];

        this._label = new St.Label({
            text: 'Ładowanie...',
            y_align: Clutter.ActorAlign.CENTER,
        });

        // Cyfry o stałej szerokości (tnum), żeby czas nie "tańczył".
        // Działa w czcionkach, które mają tę funkcję OpenType (np. Cantarell, Inter).
        try {
            const attrs = new Pango.AttrList();
            attrs.insert(Pango.attr_font_features_new('tnum=1'));
            this._label.clutter_text.set_attributes(attrs);
        } catch (e) {
            console.warn(`Serek: nie udało się włączyć cyfr o stałej szerokości: ${e}`);
        }
        this._label.clutter_text.set_line_alignment(Pango.Alignment.CENTER);
        this.add_child(this._label);

        this._buildMenu(openPrefs);

        this._settingsIds.push(this._settings.connect('changed', (_s, key) => {
            if (key === 'position')
                return; // obsługuje Extension (przebudowa wskaźnika)
            this._syncMenu();
            this._restyle();
            this._tick();
        }));

        this._restyle();
        this._tick();
        this._timeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1000, () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
    }

    // Menu po kliknięciu = odpowiednik tooltipa/zasobnika z wersji Tkinter
    _buildMenu(openPrefs) {
        this._switches = {};
        const add = (title, key) => {
            const item = new PopupMenu.PopupSwitchMenuItem(
                title, this._settings.get_boolean(key));
            item.connect('toggled', (_i, state) => {
                this._settings.set_boolean(key, state);
            });
            this.menu.addMenuItem(item);
            this._switches[key] = item;
        };
        add('Napis „Do końca:”', 'show-end-label');
        add('Cień tekstu', 'shadow');
        add('Własne tło', 'draw-background');
        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addAction('Ustawienia…', () => openPrefs());
    }

    _syncMenu() {
        for (const [key, item] of Object.entries(this._switches)) {
            const value = this._settings.get_boolean(key);
            if (item.state !== value)
                item.setToggleState(value);
        }
    }

    _restyle() {
        const s = this._settings;
        const size = s.get_int('font-size');
        const parts = [
            `color: ${this._warning ? s.get_string('warn-color') : s.get_string('text-color')}`,
            `font-size: ${size}pt`,
            `font-weight: ${s.get_boolean('font-bold') ? 'bold' : 'normal'}`,
        ];

        const family = s.get_string('font-family').replace(/["';{}]/g, '');
        if (family !== '')
            parts.push(`font-family: "${family}"`);

        if (s.get_boolean('draw-background')) {
            parts.push(`background-color: ${s.get_string('bg-color')}`);
            parts.push('border-radius: 6px');
            parts.push('padding: 1px 10px');
        } else {
            parts.push('padding: 0 8px');
        }

        const alpha = s.get_int('outline-alpha');
        if (s.get_boolean('shadow') && alpha > 0) {
            const off = Math.max(1, Math.round(size / 8));
            const color = hexToRgba(s.get_string('outline-color'), alpha / 100);
            parts.push(`text-shadow: ${off}px ${off}px 2px ${color}`);
        }

        this._label.set_style(parts.join('; '));
        this._measure();
    }

    // Stała szerokość = najszerszy możliwy stan w wybranej czcionce
    _measure() {
        const label = this._label;
        const showEnd = this._settings.get_boolean('show-end-label');
        const candidates = [WEEKEND_TEXT, DONE_TEXT];
        for (let d = 0; d < 10; d++) {
            const t = `${d}${d}:${d}${d}`;
            candidates.push(`Do dzwonka: ${t}`);
            candidates.push(`${showEnd ? 'Do końca: ' : ''}${t}`);
        }

        const saved = label.text;
        label.set_width(-1);
        let max = 0;
        for (const c of candidates) {
            label.text = c;
            const [, nat] = label.get_preferred_width(-1);
            max = Math.max(max, nat);
        }
        label.text = saved;
        this._fixedWidth = max;
        this._applyWidth();
    }

    // Normalnie stała szerokość; jeśli tekst jest szerszy (np. 430:00 rano) –
    // chwilowo poszerzamy, żeby nie został ucięty.
    _applyWidth() {
        this._label.set_width(-1);
        const [, nat] = this._label.get_preferred_width(-1);
        this._label.set_width(Math.max(nat, this._fixedWidth));
    }

    _tick() {
        const {text, remaining} = computeState(
            this._settings.get_boolean('show-end-label'));

        const warnMin = this._settings.get_int('warn-minutes');
        const warning = remaining >= 0 && warnMin > 0 && remaining < warnMin * 60;

        const warnChanged = warning !== this._warning;
        this._warning = warning;
        this._remaining = remaining;

        if (warnChanged)
            this._restyle();

        if (text !== this._text) {
            this._text = text;
            this._label.text = text;
            this._applyWidth();
        }
    }

    destroy() {
        if (this._timeoutId) {
            GLib.source_remove(this._timeoutId);
            this._timeoutId = 0;
        }
        for (const id of this._settingsIds)
            this._settings.disconnect(id);
        this._settingsIds = [];
        super.destroy();
    }
});

export default class SerekLekcjeExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._positionId = this._settings.connect('changed::position', () => {
            this._destroyIndicator();
            this._build();
        });
        this._build();
    }

    disable() {
        if (this._positionId) {
            this._settings.disconnect(this._positionId);
            this._positionId = 0;
        }
        this._destroyIndicator();
        this._settings = null;
    }

    _build() {
        this._indicator = new Indicator(this._settings, () => this.openPreferences());
        const box = this._settings.get_string('position'); // left / center / right
        Main.panel.addToStatusArea(this.uuid, this._indicator, 0, box);
    }

    _destroyIndicator() {
        this._indicator?.destroy();
        this._indicator = null;
    }
}
