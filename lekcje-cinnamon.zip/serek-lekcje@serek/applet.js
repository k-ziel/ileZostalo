const Applet = imports.ui.applet;
const Settings = imports.ui.settings;
const PopupMenu = imports.ui.popupMenu;
const Mainloop = imports.mainloop;
const Clutter = imports.gi.Clutter;
const Pango = imports.gi.Pango;

// ---------------------------------------------------------------------------
// Logika planu lekcji (ta sama co compute_text() w wersji Tkinter)
// ---------------------------------------------------------------------------
const LESSONS = [
    ['07:10', '07:55'], ['08:00', '08:45'], ['08:50', '09:35'],
    ['09:40', '10:25'], ['10:40', '11:25'], ['11:30', '12:15'],
    ['12:30', '13:15'], ['13:20', '14:05'], ['14:10', '14:55'],
    ['15:00', '15:45'], ['15:50', '16:35'],
];

const WEEKEND_TEXT = 'Weekend – brak lekcji';
const DONE_TEXT = 'Lekcje na dziś zakończone';

function pad(n) {
    return (n < 10 ? '0' : '') + n;
}

function toSec(hhmm) {
    const p = hhmm.split(':');
    return parseInt(p[0], 10) * 3600 + parseInt(p[1], 10) * 60;
}

function fmt(diff) {
    return pad(Math.floor(diff / 60)) + ':' + pad(diff % 60);
}

// Zwraca {text, remaining}; remaining = sekundy do końca lekcji albo -1
function computeState(showEndLabel) {
    const now = new Date();
    const dow = now.getDay(); // 0 = niedziela, 6 = sobota
    if (dow === 0 || dow === 6)
        return {text: WEEKEND_TEXT, remaining: -1};

    const t = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
    for (let i = 0; i < LESSONS.length; i++) {
        const s = toSec(LESSONS[i][0]);
        const e = toSec(LESSONS[i][1]);
        if (t >= s && t < e) {
            const left = e - t;
            return {text: (showEndLabel ? 'Do końca: ' : '') + fmt(left), remaining: left};
        } else if (t < s) {
            return {text: 'Do dzwonka: ' + fmt(s - t), remaining: -1};
        }
    }
    return {text: DONE_TEXT, remaining: -1};
}

// "rgb(r,g,b)" / "rgba(...)" / "#rrggbb" -> "rgba(r, g, b, a)"
function colorWithAlpha(color, alpha) {
    const c = String(color || '').trim();
    let m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i.exec(c);
    if (m) {
        return 'rgba(' + parseInt(m[1], 16) + ', ' + parseInt(m[2], 16) + ', ' +
            parseInt(m[3], 16) + ', ' + alpha + ')';
    }
    m = /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i.exec(c);
    if (m)
        return 'rgba(' + m[1] + ', ' + m[2] + ', ' + m[3] + ', ' + alpha + ')';
    return c;
}

// ---------------------------------------------------------------------------
// Aplet
// ---------------------------------------------------------------------------
class SerekApplet extends Applet.TextApplet {
    constructor(metadata, orientation, panelHeight, instanceId) {
        super(orientation, panelHeight, instanceId);

        this._text = '';
        this._warning = false;
        this._fixedWidth = 0;
        this._timeoutId = 0;
        this._switches = {};

        // aplet tylko dla poziomych paneli (tekst w pionowym panelu się nie mieści)
        try {
            this.setAllowedLayout(Applet.AllowedLayout.HORIZONTAL);
        } catch (e) {
            global.logWarning('Serek: setAllowedLayout: ' + e);
        }

        this.set_applet_tooltip('Serek – plan lekcji');

        // Cyfry o stałej szerokości (tnum) – działa w czcionkach, które to mają
        try {
            const attrs = new Pango.AttrList();
            attrs.insert(Pango.attr_font_features_new('tnum=1'));
            this._applet_label.clutter_text.set_attributes(attrs);
        } catch (e) {
            global.logWarning('Serek: cyfry o stałej szerokości niedostępne: ' + e);
        }
        try {
            this._applet_label.clutter_text.set_line_alignment(Pango.Alignment.CENTER);
        } catch (e) {}

        // Ustawienia (okno "Konfiguruj…" z settings-schema.json)
        this.settings = new Settings.AppletSettings(this, metadata.uuid, instanceId);
        const keys = [
            ['text-color', 'textColor'],
            ['warn-color', 'warnColor'],
            ['warn-minutes', 'warnMinutes'],
            ['use-custom-font', 'useCustomFont'],
            ['font', 'fontName'],
            ['font-size', 'fontSize'],
            ['font-bold', 'fontBold'],
            ['show-end-label', 'showEndLabel'],
            ['draw-background', 'drawBackground'],
            ['bg-color', 'bgColor'],
            ['shadow', 'shadow'],
            ['outline-color', 'outlineColor'],
            ['outline-alpha', 'outlineAlpha'],
        ];
        for (const [key, prop] of keys)
            this.settings.bind(key, prop, () => this._onSettingsChanged());

        this._buildMenu(orientation);

        this._restyle();
        this._tick();
        this._timeoutId = Mainloop.timeout_add(1000, () => {
            this._tick();
            return true;
        });
    }

    // Menu po kliknięciu = odpowiednik tooltipa/zasobnika z wersji Tkinter
    _buildMenu(orientation) {
        this.menuManager = new PopupMenu.PopupMenuManager(this);
        this.menu = new Applet.AppletPopupMenu(this, orientation);
        this.menuManager.addMenu(this.menu);

        const add = (title, prop) => {
            const item = new PopupMenu.PopupSwitchMenuItem(title, !!this[prop]);
            item.connect('toggled', (_item, state) => {
                this[prop] = state; // bind jest dwukierunkowy – zapisze do ustawień
                this._onSettingsChanged();
            });
            this.menu.addMenuItem(item);
            this._switches[prop] = item;
        };
        add('Napis „Do końca:”', 'showEndLabel');
        add('Cień tekstu', 'shadow');
        add('Własne tło', 'drawBackground');

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this.menu.addAction('Ustawienia…', () => this.configureApplet());
    }

    on_applet_clicked() {
        this.menu.toggle();
    }

    _onSettingsChanged() {
        for (const prop in this._switches) {
            const value = !!this[prop];
            if (this._switches[prop].state !== value)
                this._switches[prop].setToggleState(value);
        }
        this._restyle();
        this._tick(true);
    }

    _fontFamily() {
        if (!this.useCustomFont)
            return '';
        try {
            const desc = Pango.FontDescription.from_string(this.fontName);
            return (desc.get_family() || '').replace(/["';{}]/g, '');
        } catch (e) {
            return '';
        }
    }

    _restyle() {
        const size = this.fontSize;
        const parts = [
            'color: ' + (this._warning ? this.warnColor : this.textColor),
            'font-size: ' + size + 'pt',
            'font-weight: ' + (this.fontBold ? 'bold' : 'normal'),
        ];

        const family = this._fontFamily();
        if (family !== '')
            parts.push('font-family: "' + family + '"');

        if (this.drawBackground) {
            parts.push('background-color: ' + this.bgColor);
            parts.push('border-radius: 6px');
            parts.push('padding: 1px 10px');
        } else {
            parts.push('padding: 0 8px');
        }

        if (this.shadow && this.outlineAlpha > 0) {
            const off = Math.max(1, Math.round(size / 8));
            parts.push('text-shadow: ' + off + 'px ' + off + 'px 2px ' +
                colorWithAlpha(this.outlineColor, this.outlineAlpha / 100));
        }

        this._applet_label.set_style(parts.join('; '));
        this._measure();
    }

    // Stała szerokość = najszerszy możliwy stan w wybranej czcionce
    _measure() {
        const label = this._applet_label;
        const candidates = [WEEKEND_TEXT, DONE_TEXT];
        for (let d = 0; d < 10; d++) {
            const t = '' + d + d + ':' + d + d;
            candidates.push('Do dzwonka: ' + t);
            candidates.push((this.showEndLabel ? 'Do końca: ' : '') + t);
        }

        const saved = label.get_text();
        label.set_width(-1);
        let max = 0;
        for (const c of candidates) {
            label.set_text(c);
            const nat = label.get_preferred_width(-1)[1];
            if (nat > max)
                max = nat;
        }
        label.set_text(saved);
        this._fixedWidth = max;
        this._applyWidth();
    }

    // Normalnie stała szerokość; jeśli tekst jest szerszy (np. 430:00 rano)
    // – chwilowo poszerzamy, żeby nie został ucięty.
    _applyWidth() {
        const label = this._applet_label;
        label.set_width(-1);
        const nat = label.get_preferred_width(-1)[1];
        label.set_width(Math.max(nat, this._fixedWidth));
    }

    _tick(force) {
        const state = computeState(this.showEndLabel);
        const warnMin = this.warnMinutes;
        const warning = state.remaining >= 0 && warnMin > 0 &&
            state.remaining < warnMin * 60;

        if (warning !== this._warning) {
            this._warning = warning;
            this._restyle();
        }

        if (force || state.text !== this._text) {
            this._text = state.text;
            this.set_applet_label(state.text);
            this.set_applet_tooltip('Serek – plan lekcji: ' + state.text);
            this._applyWidth();
        }
    }

    on_applet_removed_from_panel() {
        if (this._timeoutId) {
            Mainloop.source_remove(this._timeoutId);
            this._timeoutId = 0;
        }
        if (this.settings)
            this.settings.finalize();
    }
}

function main(metadata, orientation, panelHeight, instanceId) {
    return new SerekApplet(metadata, orientation, panelHeight, instanceId);
}
